def ordered_difference_sets(set1, set2):
    """
    2개의 셋을 인자로 받아 차집합을 구하되, 양방향에 대한 차집합을 모두 구하여 반환하는 함수.
    

    Notes:
        두 차집합의 길이를 비교해 기링가 더 짧은 쪽을 먼저 반환한다
        길이가 같을 경우, 첫번째 차집합을 먼저 반환한다.

    """

    # 차집합 2개 구하기
    diff1 = set1 - set2
    diff2 = set2 - set1

    # 길이가 더 짧은 쪽을 먼저 반환한다.
    if len(diff1) > len(diff2):
        return diff2, diff1
    
    # 길이가 같을 경우, 첫번쨰 차집합을 먼저 반환한다.
    else:
        return diff1, diff2
    


# 예시 실행
result = ordered_difference_sets({1, 2, 3, 4}, {3, 4, 5, 6})
print("결과:", result)  # 출력: ({1, 2}, {5, 6})

result = ordered_difference_sets({1, 2, 3, 4}, {1, 2, 3})
print("결과:", result)  # 출력: (set(), {4})
