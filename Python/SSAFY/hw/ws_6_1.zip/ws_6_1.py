# 아래 함수를 수정하시오.
def union_sets(set1, set2):
    """
    두 개의 set을 인자로 받아 합집합을 반환하는 함수
    """
    # pass

    return set1.union(set2)

def union_multiple_sets(*sets):
    """
    최소 두 개 이상의 set이 제공되었는지 검사하고, 그렇지 않은 경우 경고 메세지를 출력하는 함수
    넘겨받은 모든 set을 순회하여 합집합을 진행한 결과를 반환
    """
    # pass

    # sets를 순회하며
    if len(sets)  < 2:     # 두 개 이상의 set이 제공되지 않았다면
        print('최소 두 개의 셋이 필요합니다.')

    add_set = set()
    # 넘겨받은 모든 set을 순회하여 합집합을 진행한 결과를 반환
    for s in sets:
        add_set = add_set.union(s)    

    return add_set


result = union_sets({1, 2, 3}, {3, 4, 5})
print(result)  # {1, 2, 3, 4, 5}

result = union_multiple_sets({1, 2}, {3, 4}, {5, 6})
print(result)  # {1, 2, 3, 4, 5, 6}

result = union_multiple_sets({1, 2})
# 출력 : 최소 두 개의 셋이 필요합니다
