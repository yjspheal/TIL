# 아래 함수를 수정하시오.
def get_keys_from_dict(dictionary):
    """
    주어진 단일 딕셔너리에서 모든 키를 리스트로 반환하는 함수
    """
    # pass

    return list(dictionary.keys())

def get_all_keys_from_dict(dictionary):
    """
    중첩된 딕셔너리 구조에서 모든 하위 딕셔너리의 키를 추출하여
    리스트로 반환하는 함수.
    
    Args:
        dictionary (dict): 키를 추출할 대상 딕셔너리
    
    Returns:
        List[str]: 모든 키들의 리스트
    """
    keys = []
    for key, value in dictionary.items():
        # 현재 레벨의 키 추가
        keys.append(key)
        # 값이 또 딕셔너리라면 재귀 호출
        if isinstance(value, dict):
            keys.extend(get_all_keys_from_dict(value))
    return keys


my_dict = {'name': 'Alice', 'age': 25}
result = get_keys_from_dict(my_dict)
print(result)  # ['name', 'age']

my_dict = {'person': {'name': 'Alice', 'age': 25}, 'location': 'NY'}
result = get_all_keys_from_dict(my_dict)
print(result)  # ['person', 'name', 'age', 'location']
