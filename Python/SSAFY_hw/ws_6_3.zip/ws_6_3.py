# 아래 함수를 수정하시오.
def intersection_sets(set1, set2):
    """
    두 개의 set을 인자로 받아 공통 요소만 모아 반환하는 함수

    Args:
        set1 (set): 첫번쨰 set
        set2 (set): 두번쨰 set
    
    Returns:
        (int, set): 교집합의 길이와 교집합

    Notes:
        두 셋의 교집합이 공집합인 경우, '공통 요소가 없습니다'라는 메세지가 출력됨
    """

    # 교집합 계산
    inter_set = set1.intersection(set2)

    # 교집합이 공집합이면
    if len(inter_set) == 0:
        print('공통 요소가 없습니다')

    # 교집합의 길이와 교집합을 return
    return len(inter_set), inter_set



result = intersection_sets({1, 2, 3}, {3, 4, 5})
print(result)  # (1, {3})

result = intersection_sets({1, 2}, {3, 4})
print(result)  # (0, set())
# 출력: 공통 요소가 없습니다
