# 아래 함수를 수정하시오.
def get_value_from_dict(d, key):
    """
    주어진 딕셔너리에서 특정 키에 해당하는 값을 가져오는 함수
    
    Args:
        d: 주어진 딕셔너리
        key: 특정 키
    
    Returns:
        str: 키에 해당하는 값 or Unknown
    """

    return d.setdefault(key, 'unknown')
    

my_dict = {'name': 'Alice', 'age': 25}
result = get_value_from_dict(my_dict, 'name')
print(result)  # Alice

result = get_value_from_dict(my_dict, 'gender')
print(result)  # Unknown
